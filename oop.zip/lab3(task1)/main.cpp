#include <iostream>
#include <string>
using namespace std;
class Area
{
    public:
    {
        double area(double l,double w)
        {
            lenght=l;
            width=w;
            return lenght*width;
        }


    }
    private:
    {
        double width;
        double lenght;
    }

};
int main()
{
    Area a;
    double l,w;
    cout<<"your area is"<<endl;
    cout<<a.area(4,6);

    return 0;
}
