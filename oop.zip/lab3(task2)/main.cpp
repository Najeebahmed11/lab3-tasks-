#include <iostream>
#include <string>
using namespace std;
class Add
{
    public:

         Add(int l,int w)
        {
            l=0;
            w=0;
        }





};
int main()
{
    int l,w;
    cout<<"your two values"<<endl;
    cin>>l>>w;
    cout<<l+w;

    return 0;
}
